import random

agreement = ["yes", "Yes", "YES", "y", "Y", "sure", "retry", "Retry", "Sure", 1]
degree = ["No","NO", "Nah", "no", "nah", 0]
norms = ["casual game", "Casual Game", "casual", "Casual", "Casual game", 1]
duo = ["double trouble", "Double Trouble", "Double trouble", "double", "trouble", "double Trouble", 2]
trip = ["triple threat", "Triple Threat", "Triple threat", "triple Threat", "Triple", "triple", 3]

global chips
chips = 25

def houseBot():
    print("             **** Welcome to the bit casino! ****              ")
    print("The House is gifting you 25 chips to start the fun!")
    gamblingTime()

def servBot():
    print("Would you kindly place your bet? How many chips will you gamble with?")
    bet = input()
    while int(bet) > chips and int(bet) < 0:
        tooBad()
    else:
        print("Are you sure you want to bet " + str(bet) + " chips?")
        exc = input()
        if exc in agreement:
            gamblingTime()
            return bet
        else:
            print("What would you like your bet to be?")
            exc2 = input()
            bet = int(exc2)
            gamblingTime()

def tooBad():
    print("Nice try bucko! Are you ready to play nice?")
    if input() in agreement:
        gamblingTime()
    else:
        print("You'll be welcomed when you have a better attitude")

def gamblingTime():
    print("Let's see what you're made of! Choose a Casual game, Double Trouble or if you're especially daring, Triple Threat!")
    choc = input()
    if choc in norms:
        noobGame()
    elif choc in duo:
        confirmedBy()
    elif choc in trip:
        holyNum()
    else:
        print("You want to try that again? If not, you can exit at any time :)")

def noobGame():
    global chips
    print("Alright casual, let's start this game. Ready?")
    answ = input()
    if answ in agreement:
        print("Would you kindly place your bet? How many chips will you gamble with?")
        bet = input()
    if (int(bet) > chips) or (int(bet) <= 0) == True:
        tooBad()
    else:
        if exc in agreement:
            an = random.randint(1, 4)
            print("Pick a number from 1 to 4. Choose Wisely!")
            cho = input()
            if cho == an:
                chips += bet
                print("A wonderful choice! You've really shown those pesky Statistics. Your new chip total is " + str(chips) + ".")
                blitzTak()
            else:
                chips -= int(bet)
                print("Awwww that's too bad. The right choise was " + str(an) + ". You have " + str(chips) + " chips remaining.")
                blitzTak()

def confirmedBy():
    global chips
    print("Fantastic choice! Let's get this party started. Ready?")
    answ = input()
    if answ in agreement:
        print("Would you kindly place your bet? How many chips will you gamble with?")
        bet = input()
    if (int(bet) > chips) or (int(bet) <= 0) == True:
        tooBad()
    else:
        if answ in agreement:
            ang = random.randint(1, 7)
            print("Pick a number from 1 to 7. I hope luck is on your side!")
            meh = input()
            if meh == ang:
                chips += int((bet * 2))
                print("Magnificent! Luck really is on your side. Your new chip total is " + str(chips) + ".")
                blitzTak()
            else:
                chips -= int(bet)
                print("Awwww don't be too harsh on yourself. The right choise was " + str(ang) + ". You have " + str(chips) + " chips remaining.")
                blitzTak()

def holyNum():
    global chips
    print("Oh? We have a bold character. Ready?")
    answ = input()
    if answ in agreement:
        print("Would you kindly place your bet? How many chips will you gamble with?")
        bet = input()
    if (int(bet) > chips) or (int(bet) <= 0) == True:
        tooBad()
    else:
        if answ in agreement:
            kan = random.randint(1, 21)
            print("Pick a number from 1 to 21. I hope you don't regret this choice!")
            chok = input()
            if chok == kan:
                chips += int((bet * 3))
                print("You're insane! Bragging rights are yours for the taking! Your new chip total is " + str(chips) + ".")
                blitzTak()
            else:
                chips -= int(bet)
                print("Awwww don't beat yourself over it though. The odds were stacked against you, the correct answer was " + str(kan) + ". You have " + str(chips) + " chips remaining.")
                blitzTak()

def blitzTak():
    print("Our establishment will be closing due to the first COVID outbreak. Thank you for your understanding. Please proceed to a kiosk where you can exchange your chips.")
    print("Thank you for your patronage")

houseBot()